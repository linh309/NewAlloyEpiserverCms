﻿define("epi-languagemanager/component/command/CommandBase", [
// Dojo base
    "dojo/_base/declare",

// Epi Framework
    "epi/shell/command/_Command",
    "epi/shell/TypeDescriptorManager",

// Language mangager
    "epi-languagemanager/component/_ExtensionContextMixin"

], function (
// Dojo base
    declare,

// Epi Framework
    _Command,
    TypeDescriptorManager,

// Language mangager
    _ExtensionContextMixin

    ) {


    return declare([_Command, _ExtensionContextMixin], {

        isBlock: function (context) {
            // summary:
            //		Check the input context is Block or not.
            // tags:
            //		protected

            return (context && TypeDescriptorManager.isBaseTypeIdentifier(context.dataType, "episerver.core.blockdata"));
        },

        isPage: function (context) {
            // summary:
            //		Check the input context is Page or not.
            // tags:
            //		protected

            return context && context.capabilities && context.capabilities.isPage;
        }
    });
});
