﻿define("epi-languagemanager/component/command/DownloadTranslationPackage", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
// epi
    "epi/shell/Downloader",

// ep cms
    "epi-cms/project/command/_ProjectCommand",

// language manager
    "epi-languagemanager/component/command/CommandBase",
    "epi-languagemanager/ModuleSettings",
// resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// dojo
    declare,
    lang,
    when,
// epi
    Downloader,
// epi cms
    _ProjectCommand,

// language manager
    CommandBase,
    ModuleSettings,
// resources
    res
) {

    return declare([_ProjectCommand], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.downloadtranslationpackage,

        // category: [readonly] String
        //      A category which provides a hint about how the command could be displayed.
        category: "publishmenu",

        // iconClass: [public] String
        //      The icon class of the command to be used in visual elements.
        iconClass: "epi-iconPackage",

        postscript: function () {
            this.inherited(arguments);
        },

        // propertiesToWatch: [public] Array
        //      A list of properties to watch for changes.
        propertiesToWatch: ["selectedProject"],

        _onPropertyChanged: function () {
            // summary:
            //      Sets canExecute, isAvailable based on the state of the model.
            // tags:
            //      protected

            if (!this.model.selectedProject) {
                return;
            }

            var hasProjectItems = this.model && this._hasProjectItem(this.model.selectedProject),
                isProjectPublished = this.model.selectedProject && this.model.selectedProject.status == "published";

            // set canExecute and isAvailable depend on project item count and status
            this.set("canExecute", !isProjectPublished && hasProjectItems);
            this.set("isAvailable", !isProjectPublished);
        },

        _hasProjectItem: function (project) {
            // summary:
            //      Check if the project contains any project items.
            // tags:
            //      protected

            return Object.keys(project.itemStatusCount).some(function (key) {
                if (project.itemStatusCount[key] > 0) {
                    return true;
                }
            });
        },

        _execute: function () {
            // summary:
            //      Gets selected project and pass its identification to server in order to get its translation package.
            // tags:
            //      protected

            var selectedProject = this.model && this.model.get("selectedProject");
            if (!selectedProject || !selectedProject.id) {                
                return;
            }

            if (!this.exportingUrl) {
                this.exportingUrl = ModuleSettings.exportingUrl;
            }

            // Builds request translation package url that used to send to server
            var exportingUrl = this.exportingUrl + '?projectId=' + selectedProject.id;

            Downloader.download(exportingUrl, selectedProject.name);
        }
    });
});