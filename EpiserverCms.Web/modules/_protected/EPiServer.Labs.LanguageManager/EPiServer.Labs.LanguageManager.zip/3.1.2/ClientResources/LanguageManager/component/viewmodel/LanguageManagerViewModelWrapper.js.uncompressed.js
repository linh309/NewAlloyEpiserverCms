﻿define("epi-languagemanager/component/viewmodel/LanguageManagerViewModelWrapper", [
    // dojo 
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",

    "dojo/aspect",
    "dojo/Deferred",
    "dojo/when",

    "epi/dependency",
    'epi/shell/widget/dialog/Dialog',

    "epi-languagemanager/widget/SourceLanguageOptions",
    // resource
    'epi/i18n!epi/cms/nls/languagemanager'
],
function (
    // dojo 
    declare,
    lang,
    array,

    aspect,
    Deferred,
    when,

    dependency,
    Dialog,

    SourceLanguageOptions,
    // resource
    res
) {

    return function (model) {

        var autoTranslate = function (originalMethod, originalArguments) {
            var confirmation = showSourceLanguageSelectorDialog(res.translatecontent.heading, res.translatecontent.description);

            return when(confirmation, function (selectedLanguage) {                
                // Call pasteItem of the model
                return originalMethod.apply(model, [selectedLanguage]);
            }, function () {
                return false;
            });
        }

        var duplicateContent = function (originalMethod, originalArguments) {
            var confirmation = showSourceLanguageSelectorDialog(res.dulicatecontent.heading, res.dulicatecontent.description);

            return when(confirmation, function (selectedLanguage) {
                // Call pasteItem of the model 
                return originalMethod.apply(model, [selectedLanguage]);
            }, function () {
                return false;
            });
        }

        var showSourceLanguageSelectorDialog = function (title, confirmationMessage) {
            var deferred = new Deferred();
            var registry = dependency.resolve("epi.storeregistry"),
                lmStore = registry.get("epi-languagemanager.language");            

            when(lmStore.query({ "contentLink": model.contentData.contentLink }), function (branches) {
                var existingLanguageBranches = array.filter(branches, function (item) {
                    return item.isCreated && model.currentItemData && item.languageID !== model.currentItemData.languageID;
                });

                if (!existingLanguageBranches || existingLanguageBranches.length == 1) {
                    deferred.resolve(null);
                }
                else {
                    when(confirmationMessage, function (message) {
                        var sourceLanguageOptions = new SourceLanguageOptions({ languageBranches: existingLanguageBranches });
                        var dialog = new Dialog({
                            destroyOnHide: true,
                            dialogClass: 'epi-dialog-confirm',
                            title: title,
                            description: message,
                            content: sourceLanguageOptions
                        });

                        dialog.on('execute', lang.hitch(this, function (selectedLanguage) {
                            deferred.resolve(dialog.content.selectedLanguage.languageID);
                        }));

                        dialog.on('cancel', lang.hitch(this, function () {
                            deferred.cancel();
                        }));

                        dialog.show();
                    });
                }
            });            

            return deferred;
        };

        aspect.around(model, "autoTranslate", function (originalMethod) {
            return function (sourceLanguage) {
                return autoTranslate(originalMethod, arguments);
            };
        });

        aspect.around(model, "duplicateContent", function (originalMethod) {
            return function (sourceLanguage) {
                return duplicateContent(originalMethod, arguments);
            };
        });

        return model;
    }
})