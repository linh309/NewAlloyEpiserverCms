﻿define("epi-languagemanager/component/command/ReplaceLanguageBranch", [
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",

// Epi CMS
    "epi-cms/contentediting/ContentActionSupport",

// Language manager
    "epi-languagemanager/component/command/_CommandWithOptions",
    "epi-languagemanager/widget/command/DuplicateContent",
    "epi-languagemanager/widget/command/AutoTranslate",

// Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo base
    declare,
    lang,

// Epi CMS
    ContentActionSupport,

// Language manager
    _CommandWithOptions,
    DuplicateContent,
    AutoTranslate,

// Resource
    res
) {

    return declare([_CommandWithOptions], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.replacecontent,

        _setupPopup: function (/*Object*/popup) {

            this.inherited(arguments);
            popup.set("headerDisplay", false);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            this.inherited(arguments);

            var item = this.model.currentItemData;
            var languageContext = this.model.context.languageContext;

            if (!item) {
                this.set("canExecute", false);
                return;
            }

            var isReadonlyVersion = item.versionStatus === ContentActionSupport.versionStatus.CheckedIn
                                    || item.versionStatus === ContentActionSupport.versionStatus.DelayedPublish,
                // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted or is an unsupported type
                disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData)
                || this.model.contentData.isDeleted || !this.isSupportedType(this.model.contentData);

            this.set("isAvailable", item.isCreated && item.canEdit && !item.isMaster && item.isActive && !isReadonlyVersion && !disabled);
            this.set("canExecute", item.isCreated && item.canEdit && !item.isMaster && item.isActive && !isReadonlyVersion && !disabled); 
        },

        getSubCommands: function (model) {
            // summary:
            //      Setup sub menu items when user click to create language branch.
            // tags:
            //      private

            var isTranslatingSystemAvailable = model.isTranslatingSystemAvailable;

            var autoTranslate = new AutoTranslate({ model: model }),
                duplicateContent = new DuplicateContent({ model: model }),
                languageBranchCommands = [
                    {
                        "label": autoTranslate.label,
                        "value": autoTranslate,
                        "disabled": isTranslatingSystemAvailable == false ? "disabled" : false
                    },
                    {
                        "label": duplicateContent.label,
                        "value": duplicateContent
                    }
                ];

            return languageBranchCommands;
        }
    });
});